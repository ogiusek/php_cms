<?php
namespace components;

class IComponents
{
  private string $class_file = "class.php";
  private string $handler_file = "admin/handler.php";
  private string $admin_file = "admin/renderer.php";
  private string $renderer_file = "renderer.php";

  private $content = null;
  public function get_file_name(string $class){
    $prefix = "components\\";
    if(substr($class, 0, strlen($prefix)) == $prefix){
      $class = substr($class, strlen($prefix));
    }
    return $class;
  }

  public function get_content(){
    return $this->content;
  }

  public function load_class(string $class_name){
    $file = $this->get_file_name($class_name)."/".$this->class_file;
    include_once $file;
  }

  public function get_instance(string $class_name, ...$params){
    $this->load_class($class_name);
    $class_name = "components\\$class_name";
    return new $class_name(...$params);
  }

  private function render_file(string $class_name, string $file){
    $class_name = $this->get_file_name($class_name);
    $file = $class_name."/$file";
    include $file;
  }

  private function render_file_with_content($content, string $file){
    if(is_string($content)){
      $class_name = get_class_of_serialized($content);
      $this->load_class($class_name);
      $content = unserialize($content);
    }else{
      $class_name = get_class($content);
    }
    $this->content = $content;
    $this->render_file($class_name, $file);
  }

  public function render($content){
    $this->render_file_with_content($content, $this->renderer_file);
  }

  public function render_without_content(string $class_name){
    $this->render_file($class_name, $this->renderer_file);
  }

  public function admin_render($content){
    $this->render_file_with_content($content, $this->admin_file);
  }

  public function form_handler(string $class_name, $content){
    $this->load_class($class_name);

    $this->content = $content;
    ob_start();
    $handler_file = $this->get_file_name($class_name)."/".$this->handler_file;
    include $handler_file;
    $response_serialized = ob_get_clean();
    if(get_class_of_serialized($response_serialized) != $class_name)
      return $response_serialized;

    $response = unserialize($response_serialized);
    return $response;
  }

  public function get_existing_components(){
    $components = [];
    $dir = __DIR__;
    $elements = scandir($dir);
    foreach($elements as $element){
      if(
        !is_file("$dir/$element/".$this->class_file) ||
        !is_file("$dir/$element/".$this->renderer_file) ||
        !is_file("$dir/$element/".$this->admin_file) ||
        !is_file("$dir/$element/".$this->handler_file)){
        continue;
      }
      $components[] = $element;
    }
    return $components;
  }
};
