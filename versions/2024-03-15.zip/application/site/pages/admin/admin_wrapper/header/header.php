<?php
$component = \component(__DIR__)
  ->css_file("header.css")
  ->js_file("header.js");

$frontend_dropdown = \components()->get_instance("Dropdown")
  ->setText("Frontend")
  ->setChildren([
    \components()->get_instance("Dropdown")
      ->setText("Pages")
      ->setLink("/admin/frontend/pages"),
      \components()->get_instance("Dropdown")
      ->setText("Components")
      ->setLink("/admin/frontend/components"),
      \components()->get_instance("Dropdown")
      ->setText("Colors")
      ->setLink("/admin/frontend/colors")
  ]);

$backend_dropdown = \components()->get_instance("Dropdown")
  ->setText("Backend")
  ->setChildren([
    \components()->get_instance("Dropdown")
      ->setText("Posts")
      ->setLink("/admin/backend/posts"),
      \components()->get_instance("Dropdown")
      ->setText("Emails")
      ->setLink("/admin/backend/emails")
  ]);

$settings_dropdown = \components()->get_instance("Dropdown")
  ->setText("CMS")
  ->setChildren([
    \components()->get_instance("Dropdown")
      ->setText("Users")
      ->setLink("/admin/settings/users"),
    \components()->get_instance("Dropdown")
      ->setText("Users rights")
      ->setLink("/admin/settings/posts"),
    \components()->get_instance("Dropdown")
      ->setText("Tabs")
      ->setLink("/admin/settings/colors"),
    \components()->get_instance("Dropdown")
      ->setText("Test")
      ->setChildrenPos(["vertical" => "start", "horizontal" => "start", "bottom" => "100%", "left" => "100%"])
      ->setChildren([
        \components()->get_instance("Dropdown")
          ->setText("Test")
          ->setLink("/admin/settings/test")
      ])
  ]);
?>

<header class="<?=$component->identifiers()?>">
  <nav>
    <ul class="row top">
      <li><a class="logo" href="/admin" aria-label="logo"><img src="/static/img/icons/logo.svg" alt="logo" loading="lazy"></a></li>
      <li><a class="title" href="/admin" aria-label="title">cms</a></li>
      <li><a class="logout" href="/admin/login" aria-label="logout"><img src="/static/img/icons/logout.svg" alt="logout" loading="lazy"></a></li>
    </ul>
    <hr>
    <ul class="row dropdowns">
      <li><?=\components()->render($frontend_dropdown)?></li>
      <li><?=\components()->render($backend_dropdown)?></li>
      <li><?=\components()->render($settings_dropdown)?></li>
    </div>
  </nav>
</header>