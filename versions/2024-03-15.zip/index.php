<?php
// echo phpversion(); // requires PHP >= 8.1
include "env.php";
require_once "application/index.php";

// if you do not have account create one with line below
\db\user\create_account("try@gmail.com", "password"); // <----------------------------------------------