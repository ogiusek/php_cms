<?php
$content = \components()->get_content();
$instance = \components()->get_instance("components");

$components = $content['components'];

foreach($components['component[]'] as $component){
  $name = key($component);
  $component_element = \components()->form_handler($name, $component[$name]);
  $instance->components[] = [$name => $component_element];
}

echo serialize($instance);