<?php
namespace components;

class Components{
  public array $components = [];
};