<?php
$content = \components()->get_content();

if(!$content->data) return;
echo \components()->render($content->data);