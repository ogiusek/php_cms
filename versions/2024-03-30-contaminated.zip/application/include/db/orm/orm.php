<?php
namespace db\orm;
require_once "structure/index.php";
require_once "querys/index.php";
