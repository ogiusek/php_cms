<?php
$content = \components()->get_content();
$component = \components()->get_instance("padding");

$component->padding = $content['padding'] ?? 0;

$component->components = serialize(\components()->form_handler("components", $content['content']));

return $component;