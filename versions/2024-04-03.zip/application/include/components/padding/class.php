<?php
namespace components;

class padding{
  public mixed $components;
  public function get_components(){
    return $this->components ?? serialize(\components()->get_instance("components"));
  }

  public float $padding = 0;

  public function __construct(){}
};