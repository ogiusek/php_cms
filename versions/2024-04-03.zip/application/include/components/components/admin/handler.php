<?php
$content = \components()->get_content();
$instance = \components()->get_instance("components");

$instance->flex_direction = $content["flex_direction"] ?? "column";
$instance->justify_content = $content["justify_content"] ?? "flex-start";
$instance->align_items = $content["align_items"] ?? "flex-start";

$components = $content['components'] ?? [];

foreach($components['component[]']??[] as $component){
  $name = key($component);
  $component_element = \components()->form_handler($name, $component[$name]);
  $instance->components[] = [$name => serialize($component_element)];
}

return $instance;