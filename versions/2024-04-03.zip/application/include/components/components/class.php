<?php
namespace components;

class components{
  public array $components = [];

  public string $flex_direction = "column";
  public string $justify_content = "flex-start";
  public string $align_items = "flex-start";
};