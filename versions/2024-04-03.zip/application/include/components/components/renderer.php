<?php
$content = \components()->get_content();
$component = \component(__DIR__)
  ->css_file("components.css");
?>
<div style="display: flex;
  flex-direction: <?=$content->flex_direction?>;
  justify-content: <?=$content->justify_content?>;
  align-items: <?=$content->align_items?>;
  width: 100%;
  height: 100%;
  flex-grow: 1;
  "
  class="<?=$component->identifiers()?>"
  >
<?php foreach ($content->components as $component) { ?>
  <?= \components()->render($component[key($component)])?>
<?php } ?>
</div>