<?php
$content = \components()->get_content();
$component = \component(__DIR__);

?>

<div>
  <div data-name="content">
    <?=\components()->admin_render($content->get_components())?>
  </div>
</div>