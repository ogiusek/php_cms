<?php
$content = \components()->get_content();
$component = \components()->get_instance("window");

$component->components = serialize(\components()->form_handler("components", $content['content']));

return $component;