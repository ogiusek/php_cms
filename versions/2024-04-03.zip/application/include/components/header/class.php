<?php
namespace components;

class header{
  public mixed $components;
  public function get_components(){
    return $this->components ?? serialize(\components()->get_instance("components"));
  }

  public function __construct(){}
};