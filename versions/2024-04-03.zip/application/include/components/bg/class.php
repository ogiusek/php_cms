<?php
namespace components;

\components()->load_class("components");

class bg{
  public mixed $components;
  public function get_components(){
    return $this->components ?? serialize(\components()->get_instance("components"));
  }

  public string $color = "ffffff00";

  public function __construct(){}
};