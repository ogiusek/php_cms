function handle_fetch(response){
  return new Promise(async (resolve, reject)=>{
    const text = await response.text();
    // console.log(text);
    const json = JSON.parse(text);
    // const json = await response.json();
    if(json['error']) return reject(json['content']);
    resolve(json['content']);
  });
}

function fetch_replace(url, element){
  fetch(url)
    .then(handle_fetch)
    .then(content => (element.innerHTML = content))
    .catch(notify)
}