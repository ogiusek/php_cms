<?php
\request\verify()
  ->allowed_methods(["PUT"])
  ->require_url_params(["id"]);

$content = \db\pages\content\get_by_id($_GET["id"])[0]["content"];
$class_name = get_class_of_serialized($content);
$data = \components()->form_handler($content);
if(get_class($data) != $class_name){
  \request\response()
    ->isError()
    ->setStatus(501)
    ->setContent("Not yet implemented")
    ->send();
}
\db\pages\content\edit($_GET["id"], serialize($data));

\request\response()
  ->setContent("Edited successfully")
  ->send();