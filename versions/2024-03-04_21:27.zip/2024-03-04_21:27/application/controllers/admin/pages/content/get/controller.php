<?php
\request\verify()
  ->require_session_token()
  ->allowed_methods(["GET"])
  ->required_params(["page_id"]);

ob_start();
admin_pages_content_form((int)$_POST["page_id"]);
$html = ob_get_clean();

\request\response()
  ->setContent($html)
  ->send();