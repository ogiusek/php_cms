<?php
\request\verify()
  ->require_session_token()
  ->allowed_methods(["GET"]);

ob_start();
admin_components_form();
$html = ob_get_clean();

\request\response()
  ->setContent($html)
  ->send();
