<!DOCTYPE html>
<html lang="en">

<head --="">
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width" />
  <meta name="author" content="ogius">
  <meta name="copyright" content="ogius">
  <meta name="robots" content="index, follow">
  <meta name="googlebot" content="index, follow">
  <!-- links -->
  <!-- enter today -->
  <?php $last_update = "2024-03-03_23:59:59"; ?>
  <?php $last_update = date("Y-m-d_H:i:s"); // while develop set's last update to now ?>
  <link rel="stylesheet" href="/static/css/style.css?version=<?= $last_update ?>">
  <?php foreach (["fetch.js", "notify.js", "index.js"] as $file) {
    echo "<script src=\"/static/js/$file?version=$last_update\" defer></script>";
  }?>
  <!-- jquery -->
  <!-- <script src="/static/other/jquery/jquery.min.js"></script> -->
  <!-- bootstrap -->
  <!-- <link rel="stylesheet" href="/static/other/bootstrap/css/bootstrap.min.css"> -->
  <!-- <script src="/static/other/bootstrap/js/bootstrap.bundle.min.js"></script> -->
</head>

<body>
  <?php
    require_once "lib/include.php";         // user functions
  ?>
  <?= \display_page() ?>
</body>

</html>