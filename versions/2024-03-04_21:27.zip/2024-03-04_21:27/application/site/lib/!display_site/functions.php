<?php
namespace display_site;

// define route
$route = explode('?', $_SERVER['REQUEST_URI'])[0] ?? '/';
$route = $route[-1] == '/' && strlen($route) > 1 ? substr($route, 0, -1) : $route;

// get routes
$routes = \db\pages\select_pages();

// add to file $pages_dir
$pages_directory = dirname(__DIR__, 2).'/pages';
$routes = \array_map(function ($route) use($pages_directory) {
  $route['file'] = "$pages_directory/".$route['file'];
  return $route;
}, $routes);

$matched_routes = array_filter($routes, function ($route_object) use ($route) {
  // $pattern = '(?<=\/)(\$[^\/]+)(?=\/|$)'; // matches $variable
  $variable_regex = '(?<=\/|)(\$\w*)(?=\/|$)'; // matches $ or $variable_name
  $variable_as_regex = '[a-zA-Z0-9]{0,}'; // replacement matches route
  $route_regex = str_replace('/', '\/', $route_object['page']);
  $route_regex = preg_replace("/$variable_regex/", "$variable_as_regex\\", $route_regex);
  $route_regex = $route_regex[-1] == "\\" ? substr($route_regex, 0, -1) : $route_regex;
  return preg_match("/^$route_regex$/", $route);
});
$matched_routes = array_values($matched_routes);

function route_do_not_exists() {
  global $routes, $route;
  $page = $routes[0]['page'];
  if($route != $page){
    header("Location: " . $page);
  }
  exit();
}

$GLOBALS['route'] = $route;
$GLOBALS['route_file'] = $matched_routes[0]['file']?? route_do_not_exists();
$GLOBALS['page_id'] = $matched_routes[0]['id']?? route_do_not_exists();

function display_page() {
  ob_start();
  require $GLOBALS['route_file'];
  return ob_get_clean();
}

function get_and_remove_all_tags($tag, $html){
  $regex = "/<{$tag}>(.*?)<\/{$tag}>/s";
  $tags_content = "";
  if (preg_match_all($regex, $html, $matches)) {
    foreach ($matches[1] as $key => $value) {
      $tags_content .= "\n" . $value;
    }
    foreach ($matches[0] as $key => $value) {
      $html = str_replace($value, "", $html);
    }
  }
  return ["html" => $html, "value" => $tags_content];
}

function move_tag_to(string $tag, string $target, string $html){
  $result = get_and_remove_all_tags($tag, $html);
  $html = $result["html"];
  $to_replace = "</$target>";
  $replace_with = "<$tag>" . $result["value"] . "</$tag></$target>";
  // $html = str_replace($to_replace, $replace_with, $html);
  $html = \str_replace_one($to_replace, $replace_with, $html);
  return $html;
}


function move_all_tags($html){
  $actions = [
    function ($html) { return move_tag_to("head", "head", $html); },
    function ($html) {
      // return move_tag_to("script", "body", $html);
      $js = get_and_remove_all_tags("script", $html);
      $_SESSION["js"] = $js["value"];
      $html = $js["html"];
      $html = \str_replace_one("</head>", "<script src=\"/api/compress/js?v=".time()."\" defer></script></head>", $html);
      return $html;
    },
    function ($html) {
      // return move_tag_to("style", "head", $html);
      $css = get_and_remove_all_tags("style", $html);
      $_SESSION["css"] = $css["value"];
      $html = $css["html"];
      $html = \str_replace_one("</head>", "<link rel=\"stylesheet\" href=\"/api/compress/css?v=".time()."\"></head>", $html);
      return $html;
    },
  ];

  foreach ($actions as $action) {
    $html = $action($html);
  }


  return $html;
}