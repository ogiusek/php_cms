<?php
$component = \component(__DIR__)
  ->css_file("header.css")
  ->js_file("header.js");

\components()->load_class("Dropdown");
$frontend_dropdown = (new \Dropdown())
  ->setText("Frontend")
  ->setChildren([
    (new \Dropdown())
      ->setText("Pages")
      ->setLink("/admin/frontend/pages"),
    (new \Dropdown())
      ->setText("Components")
      ->setLink("/admin/frontend/components"),
    (new \Dropdown())
      ->setText("Colors")
      ->setLink("/admin/frontend/colors")
  ]);

$backend_dropdown = (new \Dropdown())
  ->setText("Backend")
  ->setChildren([
    (new \Dropdown())
      ->setText("Posts")
      ->setLink("/admin/backend/posts"),
    (new \Dropdown())
      ->setText("Emails")
      ->setLink("/admin/backend/emails")
  ]);

$settings_dropdown = (new \Dropdown())
  ->setText("CMS")
  ->setChildren([
    (new \Dropdown())
      ->setText("Users")
      ->setLink("/admin/settings/users"),
    (new \Dropdown())
      ->setText("Users rights")
      ->setLink("/admin/settings/posts"),
    (new \Dropdown())
      ->setText("Tabs")
      ->setLink("/admin/settings/colors"),
    (new \Dropdown())
      ->setText("Test")
      ->setChildrenPos(["vertical" => "start", "horizontal" => "start", "bottom" => "100%", "left" => "100%"])
      ->setChildren([
        (new \Dropdown())
          ->setText("Test")
          ->setLink("/admin/settings/test")
      ])
  ]);
?>

<header class="<?=$component->identifiers()?>">
  <nav>
    <ul class="row top">
      <li><a class="logo" href="/admin" aria-label="logo"><img src="/static/img/icons/logo.svg" alt="logo" loading="lazy"></a></li>
      <li><a class="title" href="/admin" aria-label="title">cms</a></li>
      <li><a class="logout" href="/admin/login" aria-label="logout"><img src="/static/img/icons/logout.svg" alt="logout" loading="lazy"></a></li>
    </ul>
    <hr>
    <ul class="row dropdowns">
      <li><?=\components()->render($frontend_dropdown)?></li>
      <li><?=\components()->render($backend_dropdown)?></li>
      <li><?=\components()->render($settings_dropdown)?></li>
    </div>
  </nav>
</header>