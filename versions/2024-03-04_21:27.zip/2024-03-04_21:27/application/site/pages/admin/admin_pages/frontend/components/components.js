// const components_id = Number("<?=$component->id()?>");

function fetch_components(){
  fetch_replace('/api/admin/components/get',document.getElementById(`components-${components_id}`));
}

function add_component(id){
  const form = document.getElementById(`create-component-${id}`);
  const class_name = form.querySelector('[name=class_name]');

  fetch('/api/admin/components/add', {
    method: 'POST',
    body: JSON.stringify({
      'class_name': class_name.value
    })
  }).then(handle_fetch)
    .then(()=> {
      class_name.value = '';
      notify('Components added!', 'success');
      fetch_components();
    })
    .catch(notify);
}

function delete_component(id){
  fetch('/api/admin/components/delete', {
    method: 'DELETE',
    body: JSON.stringify({
      'id': id
    })
  }).then(handle_fetch)
    .then(()=>{
      notify('Component deleted!', 'success');
      document.querySelector(`#components-${components_id} .edit-form[data-id="${id}"]`).remove();
    })
    .catch(notify);
}

function edit_component(id){
  const form = document.querySelector(`#components-${components_id} .edit-form[data-id="${id}"]`);
  const class_name = form.querySelector('[name=class_name]');

  fetch('/api/admin/components/edit', {
    method: 'PUT',
    body: JSON.stringify({
      'id': id,
      'class_name': class_name.value
    })
  }).then(handle_fetch)
    .then(()=>{
      notify('Page updated!', 'success');
    })
    .catch(notify);
}