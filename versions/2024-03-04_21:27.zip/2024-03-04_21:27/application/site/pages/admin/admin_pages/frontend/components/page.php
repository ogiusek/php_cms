<?php
$component = \component(__DIR__)
  ->css_file("components.css")
  ->js_file("components.js");
echo "<script>components_id = ".$component->id().";</script>";
?>

<section class="<?=$component->identifiers()?>">
  <form action="javascript:add_component(<?=$component->id()?>)" id="create-component-<?=$component->id()?>" class="create-form">
    <div class="input">
      <h2>Create Component</h2>
    </div>
    <div class="input">
      <input type="text" placeholder="MyClass" name="class_name" aria-label="class_name"
      maxlength="255" title="class handled by functions" required>
    </div>
    <div class="input">
      <button type="submit">Create</button>
    </div>
  </form>

  <ul id="components-<?=$component->id()?>">
    <?php admin_components_form(); ?>
  </ul>
</section>