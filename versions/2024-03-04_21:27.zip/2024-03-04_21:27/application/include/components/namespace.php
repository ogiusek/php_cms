<?php
namespace components;

class IComponents
{
  private string $class_file = "class.php";
  private string $handler_file = "admin/handler.php";
  private string $admin_file = "admin/renderer.php";
  private string $renderer_file = "renderer.php";

  private $content = null;
  public function get_content(){
    return $this->content;
  }

  public function load_class(string $class_name){
    $file = "$class_name/".$this->class_file;
    include_once $file;
  }

  public function load_class_from_content(string $content_serialized){
    $class_name = get_class_of_serialized($content_serialized);
    return $this->load_class($class_name);
  }

  private function render_file($content, $file){
    if(is_string($content)){
      $class_name = get_class_of_serialized($content);
      $this->load_class($class_name);
      $content = unserialize($content);
    }else{
      $class_name = get_class($content);
    }
    $this->content = $content;
    $file = "$class_name/$file";
    include $file;
  }

  public function render($content){
    $this->render_file($content, $this->renderer_file);
  }

  public function admin_render($content){
    $this->render_file($content, $this->admin_file);
  }

  public function form_handler(string $content_type){
    $class_name = get_class_of_serialized($content_type);
    $this->load_class($class_name);

    ob_start();
    include "$class_name/" . $this->handler_file;
    $response_serialized = ob_get_clean();
    $response = unserialize($response_serialized);
    return $response;
  }
};
