<?php
$form_data = &$_POST;
$element = new test();
$element->a = $form_data["a"];
echo serialize($element);