<?php
$content = \components()->get_content();
?>
<div class="input">
  <input type="text" name="a" value="<?=$content->a?>">
</div>