<?php
class test {
  public string $a = "brock";
};