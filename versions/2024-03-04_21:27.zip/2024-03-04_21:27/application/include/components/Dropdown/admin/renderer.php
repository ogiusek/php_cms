<?php
$content = \components()->get_content();
\component(__DIR__)
  ->css_file("dropdown.css")

?>

<div class="<?=$component->identifiers()?>">
  <div class="input">
    <label for="text">name</label>
    <input type="text" name="text" required
      aria-label="text" maxlength="255" title="Page address" value="<?=$page['page']?>">
  </div>
  <!-- <input value="<?=$content->text?>" type="text" name="text"  /> -->
  <span><?=$content->text?></span>
</div>