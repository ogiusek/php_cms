<?php
class Dropdown {
  public string $text = "";
  public function setText(string $text) {
    $this->text = $text;
    return $this;
  }

  public string $link = "";
  public function setLink(string $link) {
    $this->link = $link;
    return $this;
  }

  public array $children = [];
  public function setChildren(array $children) {
    $this->children = $children;
    return $this;
  }
  public array $children_pos = ["vertical" => "start", "horizontal" => "center", "bottom" => "0", "left" => "50%"];
  public function setChildrenPos(array $children_pos) {
    $this->children_pos = $children_pos;
    return $this;
  }

  public function __construct() {}
};
