<?php
class first_component {
  public int $a = 17;
};