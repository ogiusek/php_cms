<?php
$content = \components()->get_content();
?>
<div class="input">
  <input type="number" name="a" value="<?=$content->a?>">
</div>