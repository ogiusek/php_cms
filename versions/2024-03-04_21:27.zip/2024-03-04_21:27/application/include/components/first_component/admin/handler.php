<?php
$form_data = &$_POST;
$element = new first_component();
$element->a = $form_data["a"];
echo serialize($element);