<?php
class my{
   public string $example_variable = "default value";
};