<?php
$component = new my();
$component->example_variable = $_POST['input_name'];
echo serialize($component);