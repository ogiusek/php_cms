<?php
$content = \components()->get_content();
?>
<div class="input">
  <label for="input_name">example_variable value</label>
  <input type="text" name="input_name" value="<?=$content->example_variable?>">
</div>