<?php
$content = \components()->get_content();
?>
<h2><?=$content->example_variable?></h2>