<?php
function admin_components_form() {
  $components = \db\components\get(); // add element to start of pages
  array_unshift($components, ["disabled" => ""]);
  foreach($components as $component) {
    $is_disabled = isset($component['disabled']) ? 'disabled' : '';
    $need_default_values = ['id', 'renderer', 'admin_renderer', 'form_handler', 'class_name'];
    foreach($need_default_values as $value) {
      $component[$value] ??= '';
    }
    ?>
    <li><form class="edit-form" action="javascript:edit_component(`<?=$component['id']?>`)" data-id="<?=$component['id']?>">
      <div class="row">
        <div class="input">
          <input type="text" placeholder="MyClass" name="class_name" aria-label="class_name" required
            maxlength="255" title="class handled by functions" value="<?=$component['class_name']?>" <?= $is_disabled ?>>
        </div>
      </div>
      <?php if(!$is_disabled){ ?>
      <div class="row" style="justify-content: end; margin-left: auto">
        <div class="input button">
          <button type="submit">edit</button>
          <button type="button" class="remove" onclick="delete_component(`<?=$component['id']?>`)">remove</button>
        </div>
      </div>
      <?php } ?>
    </form></li>
  <?php } ?>
<?php } ?>