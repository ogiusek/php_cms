<?php
function admin_pages_content_form($page_id) {
  ?>
  <form class="content-add-form" id="add-content-<?=$page_id?>" action="javascript:add_page_content(<?=$page_id?>)">
    <div class="input">
      <label for="class_name">component class</label>
      <select name="class_name">
        <?php
        $components = \db\components\get();
        foreach($components as $component) {
          ?>
          <option value="<?=$component['class_name']?>"><?=$component['class_name']?></option>
        <?php } ?>
      </select>
    </div>
    <div class="input button">
      <button type="submit">add</button>
    </div>
  </form>
  <ul class="content-list">
  <?php
  $contents = \db\pages\content\get($page_id);  
  foreach($contents as $content) {
    $element_id = "content-". $content['id'];
    // echo json_encode($content['content']);
    $content_obj = $content['content'];
    ?>
    <li id="<?=$element_id?>" class="content-item">
      <h3><?=get_class_of_serialized($content_obj)?></h3>
      <div>
        <?php \components()->admin_render($content_obj); ?>
      </div>
      <div class="input button" style="margin-left: auto">
        <button class="edit" onclick="edit_page_content(<?=$content['id']?>, '<?=$element_id?>')">edit</button>
        <button class="remove" onclick="remove_page_content(<?=$content['id']?>, '<?=$element_id?>')">remove</button>
      </div>
    </li>
  <?php } ?>
  </ul>
<?php } ?>
