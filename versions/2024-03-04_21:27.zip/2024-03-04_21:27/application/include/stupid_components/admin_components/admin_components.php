<?php
$components = scandir(__DIR__);
$components = array_diff($components, [".", "..", "admin_components.php"]);
foreach ($components as $component) {
  require_once $component;
}
