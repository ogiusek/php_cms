<?php
function str_replace_one(string $search, string $replace, string $originalString) {
  $position = strpos($originalString, $search);
  
  if ($position !== false) {
    $newString = substr_replace($originalString, $replace, $position, strlen($search));
    return $newString;
  } else {
    return $originalString;
  }
}

function initialize_class_from_string(string $class_name){
  $ref = new \ReflectionClass($class_name);
  return $ref->newInstance();
}

function get_class_of_serialized(string $serialized){
  $splitted = explode(":", $serialized);
  $class_name_length = $splitted[1];
  $data =  $splitted[2];
  $class_name = substr($data, 1, $class_name_length);
  return $class_name;
}
