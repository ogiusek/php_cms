<?php
require_once "css/css.php";
require_once "namespace.php";

function &component(string $dir = "") {
  static $components = [];
  if (isset($components[$dir])) {
    return $components[$dir];
  }
  $components[$dir] = new \component\IComponent("$dir/");
  return $components[$dir];
}
