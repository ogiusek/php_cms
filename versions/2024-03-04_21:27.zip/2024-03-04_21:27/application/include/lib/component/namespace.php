<?php
namespace component;

function getUniqueID() {
  static $id = 0;
  return ++$id;
}

$component_class = "component-class";
$component_unique_class = "component-unique-class-";

class IComponent {
  private string $parent_dir = "";
  private int $id = -1;
  private \css\ICSS $css;

  public function id(){
    return $this->id;
  }

  public function js_file(string $path): self {
    $path = $this->parent_dir . $path;
    $js = file_get_contents($path);
    echo "<script>$js</script>";
    return $this;
  }

  private function css_id(): string {
    global $component_unique_class;
    return $component_unique_class . $this->id;
  }

  public function css_file(string $path): self {
    global $component_class;
    $path = $this->parent_dir . $path;
    $this->css
      ->load_css_from_path($path)
      ->format($this->css_id(), $component_class)
      ->echo();
    return $this;
  }

  function identifiers(): string {
    global $component_class;
    $class = "$component_class";
    $id = $this->css_id();
    return "$class $id";
  }

  function __construct(string $dir) {
    global $component_class;
    $this->parent_dir = $dir;
    $this->id = getUniqueID();
    $this->css = \css();
  }
}