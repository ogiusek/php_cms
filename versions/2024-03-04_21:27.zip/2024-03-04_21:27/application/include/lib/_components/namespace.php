<?php
namespace components;

// function initialize_class_from_string($class_name){
//   $ref = new \ReflectionClass($class_name);
//   return $ref->newInstance();
// }

class Mediator{
  private $handlers = [];

  public function add_handler($content_class, $handler){
    $this->handlers[$content_class] = $handler;
  }

  public function handle($content){
    $handler_name = get_class($content);
    if(array_key_exists($handler_name, $this->handlers)){
      return $this->handlers[$handler_name]($content);
    }
    return "Not found handler for $handler_name";
  }
};

class IComponents {
  private array $componenets_initializer;

  private bool $initialized_components = false;
  private Mediator $components_mediator;

  private bool $initialized_admin_components = false;
  private Mediator $admin_components_mediator;

  private bool $initialized_form_handlers = false;
  private array $form_handlers;

  private function initialize_components(): self {
    if($this->initialized_components) return $this;
    $this->initialized_components = true;
    foreach ($this->componenets_initializer as $component) {
      $this->components_mediator->add_handler($component["class_name"], $component["renderer"]);
    }
    return $this;
  }

  private function initialize_admin_components(): self {
    if($this->initialized_admin_components) return $this;
    $this->initialized_admin_components = true;
    foreach ($this->componenets_initializer as $component) {
      $this->admin_components_mediator->add_handler($component["class_name"], $component["admin_renderer"]);
    }
    return $this;
  }

  private function initialize_form_handlers(): self {
    if($this->initialized_form_handlers) return $this;
    $this->initialized_form_handlers = true;
    foreach ($this->componenets_initializer as $component) {
      $this->form_handlers[$component["class_name"]] = $component["form_handler"];
    }
    return $this;
  }


  public function render(string $content_serialized){
    $this->initialize_components();
    $content = unserialize($content_serialized);
    return $this->components_mediator->handle($content);
  }

  public function admin_render($content){
    $this->initialize_admin_components();
    return $this->admin_components_mediator->handle($content);
  }

  public function form_handler($content_type){
    $this->initialize_form_handlers();
    return $this->form_handlers[$content_type]();
  }

  public function __construct() {
    $this->componenets_initializer = \db\components\get();

    $this->components_mediator = new Mediator();
    $this->admin_components_mediator = new Mediator();
    $this->form_handlers = [];
  }
};