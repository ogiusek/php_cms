<?php
require_once "namespace.php";

function &components(): \components\IComponents {
  static $components;
  $components ??= new \components\IComponents();
  return $components;
}

// class Test{
//   public int $a = 1;
//   public function add() {
//     $this->a++;
//     return $this;
//   }
// };

// function &Test(){
//   static $counter;
//   $counter ??= new Test();
//   return $counter;
// }

// echo Test()->a; // 1
// $var =& Test();
// $var->a++;
// echo Test()->a; // 2
// Test()->add();
// echo Test()->a; // 3

