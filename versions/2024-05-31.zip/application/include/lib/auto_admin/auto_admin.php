<?php
require_once "auto_handle.php";
require_once "auto_admin_render.php";