<?php
\request\verify()
  ->require_session_token();
// TODO