<?php
namespace components;

class header{
  public string $logo = "/img/icons/logo.svg";
  public array $dropdowns = [];
};
