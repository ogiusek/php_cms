<?php
$content = \components()->get_content();
$html = $content->get_html();
?>
<?=$html?>