<?php
namespace components;

class title{
  public string $title = "unique title for this page";
}