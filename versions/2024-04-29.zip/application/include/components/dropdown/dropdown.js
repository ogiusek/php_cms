function load_dropdowns() {
  [...document.querySelectorAll(".dropdown-container>.dropdown")].map(element => {
    if (element.getBoundingClientRect().left < 0 || element.getBoundingClientRect().right > window.innerWidth) {
      element.parentElement.classList.add("default");
    }else{
      element.parentElement.classList.remove("default");
    }
  });
}

document.addEventListener("DOMContentLoaded", load_dropdowns);
window.addEventListener("resize", load_dropdowns);
