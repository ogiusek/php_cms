function remove_dropdown(button){
  button.parentElement.parentElement.remove();
}

function add_dropdown(button){
  const element = button.parentElement.parentElement;
  element.insertAdjacentHTML('beforeend', `
  <div class="child" data-name="children[]">
    <div class="input" style="display: flex; flex-direction: row; gap: 1rem;">
      <button class="remove" data-alt="remove" onclick="remove_dropdown(this);"><img src="/static/img/icons/trash.svg" alt="remove" loading="lazy" /></button>
      <button class="toggle" data-alt="toggle" onclick="this.parentElement.parentElement.querySelector('.toggle-content').classList.toggle('hidden')"><img src="/static/img/icons/dropdown.svg" alt="toggle" loading="lazy" /></button>
    </div>
    <div class="toggle-content hidden">
      <div class="element"></div>
    </div>
  </div>`);
  const new_element = element.querySelectorAll('.element');
  const url_search_params = new URLSearchParams({"class_name": "dropdown"});
  fetch_replace(`/api/components/admin_render?${(url_search_params.toString())}`, [...new_element]);
}
