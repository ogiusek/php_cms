<?php
$content = \components()->get_content();
$component = \component(__DIR__)
  ->css_file("header.css");
?>

<header class="<?=$component->identifiers()?>" data-refresh="header">
  <div class="icon-parent">
    <?php
    $image = \components()->get_instance("image");
    $image->set_src("/".$content->logo);
    echo \components()->render($image);
    ?>
  </div>
  <div class="dropdowns hide">
    <?php foreach ($content->dropdowns as $dropdown) { ?>
      <?=\components()->render($dropdown)?>
    <?php } ?>
  </div>
  <button class="toggle_dropdowns icon-parent" onclick="this.parentElement.querySelector('.dropdowns').classList.toggle('hide')">
    <?php
      $image = \components()->get_instance("image");
      $image->set_src("/img/icons/menu.svg");
      echo \components()->render($image);
    ?>
  </button>
</header>