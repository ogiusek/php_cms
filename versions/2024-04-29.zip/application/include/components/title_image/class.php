<?php
namespace components;

class title_image{
  public string $src = '.png';
  public string $title = 'example title';
  public string $text = 'very long messeage to audience';
};