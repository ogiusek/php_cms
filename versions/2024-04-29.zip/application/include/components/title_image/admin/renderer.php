<?php
$content = \components()->get_content();
$component = \component(__DIR__);
?>

<div class="<?=$component->identifiers()?>">
  <div data-name="image">
    <?php $image = \components()->get_instance("image"); ?>
    <?php $image = \components()->get_instance("image")->set_src($content->href); ?>
    <?= \components()->admin_render($image) ?>
  </div>
  <div class="input">
    <label for="title">title</label>
    <input type="text" data-name="title" value="<?=$content->title?>" aria-label="title">
  </div>
  <div class="input">
    <label for="text">text</label>
    <!-- <input type="text" data-name="text" value="<?=$content->text?>" aria-label="text"> -->
    <textarea data-name="text" rows="3" aria-label="text"><?=$content->text?></textarea>
  </div>
</div>