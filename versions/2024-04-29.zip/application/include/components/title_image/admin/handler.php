<?php
$content = \components()->get_content();
$component = \components()->get_instance("title_image");

$image = \components()->form_handler("image", $content['image']??[]);
$component->href = $image->get_src();
$component->title = $content["title"] ?? $component->title;
$component->text = $content["text"] ?? $component->text;

return $component;