<?php
$content = \components()->get_content();
$component = \component(__DIR__)
  ->css_file("title_image.css");
?>

<div class="<?=$component->identifiers()?>">
  <img src="/static/<?=$content->href?>" alt="<?=$content->title?>">
  <?php if($content->text || $content->title) { ?>
  <div class="container">
    <h3><?=$content->title?></h3>
    <p><?=str_replace("\n", "<br>", $content->text)?></p>
  </div>
  <?php } ?>
</div>