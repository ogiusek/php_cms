<?php
$content = \components()->get_content();
$component = \components()->get_instance("icon");

$component->link = $content["link"] ?? $component->link;

return $component;