<?php
$component = \component(__DIR__)
  ->css_file("admin_pages_content_form.css")
  ->js_file("admin_pages_content_form.js");
$content = \components()->get_content();
$page_id = $content->page_id;
?>
<div class="<?=$component->identifiers()?>" data-refresh="admin_pages_content_form" data-initializer="<?=$page_id?>">
  <h2>page content</h2>
  <form class="content-add-form form" action="javascript:void(0)" onsubmit="add_page_content(this, <?=$page_id?>)">
    <div class="input">
      <label for="class_name">component class</label>
      <select name="class_name" aria-label="class_name">
        <option value="" disabled selected>-- select --</option>
        <?php
        $components = \db\components\get();
        foreach($components as $component) { ?>
          <option value="<?=$component['class_name']?>"><?=$component['class_name']?></option>
        <?php } ?>
      </select>
    </div>
    <div class="input button">
      <button type="submit">add</button>
      <button type="button" class="paste" onclick="paste_page_content('<?=$page_id?>')" data-alt="paste"><img src="/static/img/icons/paste.svg" alt="paste" loading="lazy" /></button>
    </div>
  </form>

  <ul class="content-list">
  <?php
  $contents = \db\pages\content\get_by_page_id($page_id);  
  foreach($contents as $content) {
    $element_id = "content-". $content['id'];
    $content_obj = $content['content'];
    $title = get_class_of_serialized($content_obj);
    $title = \components()->get_component_name($title); ?>
    <li id="<?=$element_id?>" data-id="<?=$content['id']?>" class="content-item draggable" ondragend="change_page_content_order('<?=$element_id?>')">
      <div style="display: flex; justify-content: space-between; flex-direction: row">
        <h3><?=$title?></h3>
        <div class="input button buttons">
          <button class="toggle" data-alt="toggle" onclick="this.parentElement.parentElement.parentElement.querySelector('.toggle-content').classList.toggle('hidden')"><img src="/static/img/icons/dropdown.svg" alt="toggle" loading="lazy" /></button>
          <button class="copy" data-alt="copy" onclick="copy_page_content('<?= $content['id'] ?>')"><img src="/static/img/icons/copy.svg" alt="copy" loading="lazy" /></button>
          <button class="drag-btn" data-alt="drag" onmouseup="drag_once(document.getElementById('<?=$element_id?>'))"><img src="/static/img/icons/move.svg" alt="move" loading="lazy" /></button>
          <button class="edit" data-alt="save" onclick="edit_page_content(<?=$content['id']?>, '<?=$element_id?>')"><img src="/static/img/icons/save.svg" alt="save" loading="lazy" /></button>
          <button class="remove" data-alt="remove" onclick="remove_page_content(<?=$content['id']?>, '<?=$element_id?>')"><img src="/static/img/icons/trash.svg" alt="remove" loading="lazy" /></button>
        </div>
      </div>
      <div class="toggle-content hidden">
        <?php try{ ?>
          <?=\components()->admin_render($content_obj);?>
        <?php }catch(Throwable $e){ ?>
          <h4 class="error">Cannot render this component</h4>
        <?php } ?>
      </div>
    </li>
  <?php } ?>
  </ul>
</div>