<?php
$content = \components()->get_content();
$component = \components()->get_instance("article");

$component->title = $content["title"] ?? $component->title;
$component->content = $content["content"] ?? $component->content;

return $component;