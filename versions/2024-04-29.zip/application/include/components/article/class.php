<?php
namespace components;

class article{
  public string $title = "what is this part about ?";
  public string $content = "very long monolog to very interested audience";
};