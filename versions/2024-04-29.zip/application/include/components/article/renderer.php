<?php
$content = \components()->get_content();
$component = \component(__DIR__)
  ->css_file("article.css");
?>

<article class="<?=$component->identifiers()?>">
  <h2><?=$content->title?></h2>
  <p><?=str_replace("\n", "<br>", $content->content)?></p>
</article>