<?php
namespace components;

class caruosel{
  public array $images = [];
}