<?php
$content = \components()->get_content();

$pallete = \db\colors\get_by_page_id($GLOBALS['page_id']);
$color = $pallete->colors["text-primary"];
$url_params = "url=".urlencode($content->get_src())."&color=".urlencode($color);
?>

<img src="/api/svg?<?=$url_params?>" alt="image cannot load" style="height: 100%; width: 100%; object-fit: contain;"/>
