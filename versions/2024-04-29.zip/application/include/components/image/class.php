<?php
namespace components;

class image{
  public string $image = '';
  public function get_src(){
    return $this->image;
  }
  
  public function set_src($image){
    $this->image = $image;
    return $this;
  }
  public string $object_position = '50% 50%';
  public function get_object_position(){
    return $this->object_position;
  }
  public function set_object_position($object_position){
    $this->object_position = $object_position;
    return $this;
  }

  public function __construct(string $image = ""){
    $this->image = $image;
  }
};