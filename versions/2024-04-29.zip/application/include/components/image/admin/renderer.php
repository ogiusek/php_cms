<?php
$content = \components()->get_content();
$component = \component(__DIR__)
  ->css_file("image.css")
  ->js_file("image.js");
?>

<div class="<?=$component->identifiers()?> input" data-refresh="image">
  <button class="image-button" onclick="admin_image_component_edit(this.querySelector('img').src, select_parent_component(this))" data-alt="select image">
    <input type="text" data-name="image" style="display: none;" aria-label="image">
    <img src="/static/<?=empty($content->get_src()) ? "img/icons/add.svg" : $content->get_src()?>" alt="select image">
  </button>
  <div class="input">
    <button data-alt="edit image center" class="extra-button" onclick="admin_image_select_center(this)">
      <input style="display: none;" data-name="object_position" type="text" value="<?=$content->get_object_position()?>">
      <img src="/static/img/icons/aim.svg" alt="edit image center">
    </button>
  </div>
</div>