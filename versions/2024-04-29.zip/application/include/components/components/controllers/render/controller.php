<?php
\request\verify()
  ->require_session_token()
  ->require_params(["type", "data"]);

$response = \components()->admin_render(
  \components()->form_handler($_POST["type"], $_POST["data"])
);

echo $response;