<?php
namespace components;

class components{
  public array $components = [];
  public mixed $style = null;
  public function get_style(){
    if($this->style !== null) return $this->style;
    $style = \components()->get_instance("style");
    $style->set_style("display", "flex");
    $style->set_style("flex-direction", "column");
    $style->set_style("justify-content", "flex-start");
    $style->set_style("align-items", "flex-start");
    $style->set_style("width", "100%");
    $style->set_style("height", "100%");
    // $style->set_style("flex-grow", "1");
    return serialize($style);
  }
};