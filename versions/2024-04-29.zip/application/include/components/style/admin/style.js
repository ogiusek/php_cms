/**
 * @param {HTMLElement} element 
 */
function add_style_component(element){
  const parent = select_parent_component(element);
  const ul = parent.querySelector('ul');
  const to_append = `
  <li class="style" data-name="styles[]">
    <div class="input" style="display: flex;flex-direction: row;gap: 0.5rem;">
      <input type="text" data-name="key" aria-label="key" value="" />
      <span>:</span>
      <input type="text" data-name="value" aria-label="value" value="" />
    </div>
    <div class="input" style="width: min-content;">
      <button onclick="remove_style_component(this)" class="remove" data-alt="remove">
        <img src="/static/img/icons/trash.svg" alt="remove" loading="lazy">
      </button>
    </div>
  </li>`;
  ul.insertAdjacentHTML('beforeend', to_append);
}

/**
 * @param {HTMLElement} element 
 */
function remove_style_component(element){
  const elem = select_parent_where(element, (e) => e.classList.contains("style"));
  elem.remove();
}

/**
 * @param {HTMLElement} element 
 */
function toggle_style_component(element){
  const parent = select_parent_component(element);
  const wrapper = parent.querySelector(".wrapper");
  wrapper.classList.toggle("active");
}