<?php
$content = \components()->get_content();
$component = \component(__DIR__)
  ->js_file("style.js")
  ->css_file("style.css");
?>

<div class="<?=$component->identifiers()?>" data-refresh="style">
  <div class="input">
    <button class="toggle" onclick="toggle_style_component(this)">edit style</button>
  </div>
  <div class="wrapper">
    <button class="backdrop" onclick="toggle_style_component(this)"></button>
    <div class="content">
      <div class="input">
        <button onclick="add_style_component(this)" class="add">add</button>
      </div>
      <ul class="styles">
        <?php foreach ($content->get_styles() as $key => $value) { ?>
          <li class="style" data-name="styles[]">
            <div class="input" style="display: flex;flex-direction: row;gap: 0.5rem;">
              <input type="text" data-name="key" aria-label="key" value="<?=$key?>" />
              <span>:</span>
              <input type="text" data-name="value" aria-label="value" value="<?=$value?>" />
            </div>
            <div class="input" style="width: min-content;">
              <button onclick="remove_style_component(this)" class="remove" data-alt="remove">
                <img src="/static/img/icons/trash.svg" alt="remove" loading="lazy">
              </button>
            </div>
          </li>
        <?php } ?>
      </ul>
    </div>
  </div>
</div>