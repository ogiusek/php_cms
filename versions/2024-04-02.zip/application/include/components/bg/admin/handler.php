<?php
$content = \components()->get_content();
$component = \components()->get_instance("bg");

if($content['color'][0] === "#")
  $content['color'] = substr($content['color'], 1);
$component->color = $content['color'];

$component->components = \components()->form_handler("components", $content['content']);

echo serialize($component);