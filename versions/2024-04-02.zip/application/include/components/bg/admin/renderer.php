<?php
$content = \components()->get_content();
$component = \component(__DIR__);

?>

<div>
  <div class="input">
    <label for="color">background color</label>
    <input type="text" data-name="color" aria-label="color" min="6" max="9" value="#<?=$content->color?>">
  </div>
  <div data-name="content">
    <?=\components()->admin_render($content->get_components())?>
  </div>
</div>