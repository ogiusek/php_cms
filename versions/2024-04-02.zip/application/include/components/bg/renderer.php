<?php
$content = \components()->get_content();
$component = \component(__DIR__)
  ->css_file("bg.css");
?>

<div class="<?=$component->identifiers()?> full" style="background-color: #<?=$content->color?>" data-refresh="bg">
  <?=\components()->render($content->get_components())?>
</div>