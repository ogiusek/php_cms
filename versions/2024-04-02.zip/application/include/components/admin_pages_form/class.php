<?php
namespace components;
class admin_pages_form {};