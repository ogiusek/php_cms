<?php
$content = \components()->get_content();
$component = \component(__DIR__);
?>

<?=\components()->render($content->get_components())?>