<?php
$content = \components()->get_content();
$component = \component(__DIR__);
?>

<div>
  <div class="input">
    <label for="identifier">comment</label>
    <input type="text" data-name="identifier" aria-label="identifier" value="<?=$content->identifier?>">
  </div>
  <div data-name="content">
    <?=\components()->admin_render($content->get_components())?>
  </div>
</div>