<?php
$content = \components()->get_content();
$component = \components()->get_instance("div");

$component->identifier = $content['identifier'];
$component->components = \components()->form_handler("components", $content['content']);

echo serialize($component);