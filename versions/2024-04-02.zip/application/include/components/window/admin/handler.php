<?php
$content = \components()->get_content();
$component = \components()->get_instance("window");

$component->components = \components()->form_handler("components", $content['content']);
// $component->show_bg = $content['show_bg'];

echo serialize($component);