function remove_component_from_components(button){
  select_parent_with_attr(button, 'data-type').remove();
}

function get_components_wrapper(class_name){
  return `<li data-name="component[${class_name}]" class="component draggable" data-type="${class_name}">
    <div class="input fixed_container" style="display: flex; flex-direction: row; gap: 0.5rem;">
      <button class="toggle" data-alt="toggle" onclick="toggle_components_element(this);"><img src="/static/img/icons/dropdown.svg" alt="toggle" loading="lazy" /></button>
      <button class="copy" data-alt="copy" onclick="copy_components_element(this);"><img src="/static/img/icons/copy.svg" alt="copy" loading="lazy" /></button>
      <button class="drag-btn" data-alt="drag" onmouseup="drag_once(this)"><img src="/static/img/icons/move.svg" alt="move" loading="lazy"/></button>
      <button class="remove" onclick="remove_component_from_components(this)" data-alt="remove"><img src="/static/img/icons/trash.svg" alt="remove" loading="lazy" /></button>
    </div>
    <h4 style="font-size: 1.5rem; margin-top: 0">${class_name}</h4>
    <div class="replaceMe"></div>
  </li>`;
}

function add_component_to_components(element){
  const class_name = element.querySelector("[data-name=content_type]").value;
  if(class_name === '') return notify('Please select a component', 'error');
  const content_element = element.querySelector("[data-name=components]");
  const child = get_components_wrapper(class_name);
  content_element.insertAdjacentHTML('beforeend', child);
  const new_element = [...content_element.querySelectorAll(`.replaceMe`)].at(-1);
  const url_search_params = new URLSearchParams({"class_name": class_name});
  fetch_replace(`/api/components/admin_render?${(url_search_params.toString())}`, [new_element], 'innerHTML');
}

/**
 * @param {HTMLElement} element 
 */
function copy_components_element(element){
  const wrapper = select_parent_with_attr(element, 'data-type');
  const type = wrapper.getAttribute('data-type');
  const form_data = get_form_data(wrapper);
  localStorage.setItem('components-copy', JSON.stringify({type: type, data: form_data}));
  notify('copied!', 'success');
}

/**
 * @param {HTMLElement} wrapper 
 */
function paste_components_element(wrapper){
  const data = localStorage.getItem('components-copy');
  if(!data) return;
  wrapper = wrapper.getAttribute("data-name") === "components" ? wrapper : wrapper.querySelector("[data-name=components]");
  const parsed = JSON.parse(data);
  const type = parsed.type;
  const form_data = parsed.data;
  wrapper.insertAdjacentHTML('beforeend', get_components_wrapper(type));
  const to_replace = wrapper.querySelector(".replaceMe");
  fetch_controller("components", "render", {
    type: type,
    data: form_data
  }).then(html => {
    to_replace.outerHTML = format_html(html);
  });
}

function toggle_components_element(element){
  const wrapper = select_parent_with_attr(element, 'data-type');
  wrapper.classList.toggle('hide');
}