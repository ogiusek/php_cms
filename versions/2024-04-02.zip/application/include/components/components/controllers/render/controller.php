<?php
\request\verify()
  ->require_session_token()
  ->required_params(["type", "data"]);

$response = \components()->admin_render(
  \components()->form_handler($_POST["type"], $_POST["data"])
);

echo $response;