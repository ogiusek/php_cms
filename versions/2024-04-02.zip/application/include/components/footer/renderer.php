<?php
$content = \components()->get_content();
$component = \component(__DIR__)
  ->css_file("footer.css");
?>

<footer class="<?=$component->identifiers()?>" data-refresh="footer">
  <?= \components()->render($content->get_components()) ?>
</footer>