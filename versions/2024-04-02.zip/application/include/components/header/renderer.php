<?php
$content = \components()->get_content();
$component = \component(__DIR__)
  ->css_file("header.css");
?>

<header class="<?=$component->identifiers()?>" data-refresh="header">
  <?= \components()->render($content->get_components()) ?>
</header>