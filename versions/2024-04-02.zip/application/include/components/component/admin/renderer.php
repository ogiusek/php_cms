<?php
$content = \components()->get_content();
$component = \component(__DIR__)
  ->js_file("component.js");
?>

<div>
  <div class="input">
    <label for="content_type">component type</label>
    <select data-name="content_type" aria-label="component type"
      onchange="reset_component_element_ui(this.parentNode.parentNode);"><?php
      $components = \db\components\get();
      if($content->content_type === ""){?>
        <option value="" disabled selected>-- select --</option>
      <?php }
      foreach($components as $component_data){ 
        $class_name = $component_data['class_name']; ?>
        <option value="<?=$class_name?>" <?=$class_name === $content->content_type ? "selected":""?>>
          <?=$class_name?>
        </option>
      <?php } ?>
    </select>
  </div>
  <div data-name="data">
    <?php
      if($content->content_type !== "") 
        echo \components()->admin_render($content->data?? \components()->get_instance($content->content_type)); ?>
  </div>
</div>