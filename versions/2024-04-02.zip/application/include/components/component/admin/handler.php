<?php
$instance = \components()->get_instance("component");
$content = \components()->get_content();

if(isset($content['content_type']) && $content['content_type'] !== ""){
  $instance->content_type = $content['content_type'];
  $instance->data = \components()->form_handler($instance->content_type, $content['data']?? []);
}

echo serialize($instance);