function reset_component_element_ui(element){
  const class_name = element.querySelector("[data-name=content_type]").value;
  const content_element = element.querySelector("[data-name=data]");
  const url_search_params = new URLSearchParams({"class_name": class_name});
  fetch_replace(`/api/components/admin_render?${(url_search_params.toString())}`, [content_element], 'innerHTML');
}