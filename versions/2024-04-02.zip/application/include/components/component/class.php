<?php
namespace components;

class component{
  public string $content_type = "";
  public $data;
};