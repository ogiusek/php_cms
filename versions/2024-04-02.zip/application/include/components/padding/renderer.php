<?php
$content = \components()->get_content();
$component = \component(__DIR__)
  ->css_file("padding.css");
?>


<div class="<?=$component->identifiers()?>" style="padding: <?=$content->padding?>rem" data-refresh="padding">
  <?=\components()->render($content->get_components())?>
</div>