<?php
$content = \components()->get_content();
$component = \component(__DIR__);
?>

<div>
  <div class="input">
    <label for="padding">padding (in rem)</label>
    <input type="number" data-name="padding" aria-label="padding" min="0" step="0.1" value="<?=$content->padding?>">
  </div>
  <div data-name="content">
    <?=\components()->admin_render($content->get_components())?>
  </div>
</div>