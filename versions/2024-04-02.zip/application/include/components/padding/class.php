<?php
namespace components;

\components()->load_class("components");

class padding{
  public mixed $components;
  public function get_components(){
    return $this->components ?? \components()->get_instance("components");
  }

  public float $padding = 0;

  public function __construct(){}
};