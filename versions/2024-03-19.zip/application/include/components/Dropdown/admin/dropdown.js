function remove_dropdown(button){
  button.parentElement.parentElement.remove();
}

function add_dropdown(button){
  const element = button.parentElement.parentElement;
  element.insertAdjacentHTML('beforeend', `
  <div class="child" data-name="children[]">
    <div class="element"></div>
    <div class="input">
      <button class="remove" data-alt="remove" onclick="remove_dropdown(this);"><img src="/static/img/icons/trash.svg" alt="remove" /></button>
    </div>
  </div>`);
  const new_element = element.querySelectorAll('.element');
  const url_search_params = new URLSearchParams({"class_name": "Dropdown"});
  fetch_replace(`/api/components/admin_render?${(url_search_params.toString())}`, [...new_element]);
}
