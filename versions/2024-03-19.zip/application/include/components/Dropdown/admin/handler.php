<?php
$content = \components()->get_content();

$children = array_map(function ($element) {
  return unserialize(\components()->form_handler("Dropdown", $element));
}, $content['children[]']??[]);

$component = \components()->get_instance("Dropdown")
  ->setText($content['text']??"")
  ->setLink($content['link']??"")
  ->setChildren($children);

echo serialize($component);