<?php
namespace head;

class head {
  private string $head = "";

  public function echo() {
    echo "<head>$this->head</head>";
  }

  public function icon(string $icon): self {
    $this->head .= "<link rel=\"icon\" href=\"$icon\">";
    return $this;
  }

  public function image(string $image): self {
    $this->head .= "<meta property=\"og:image\" content=\"$image\">";
    return $this;
  }

  public function title(string $title): self {
    $this->head .= "<meta property=\"og:title\" content=\"$title\">";
    $this->head .= "<title>$title</title>";
    return $this;
  }

  public function description(string $description): self {
    $this->head .= "<meta name=\"description\" content=\"$description\">";
    $this->head .= "<meta property=\"og:description\" content=\"$description\">";
    return $this;
  }

  public function keywords(string $keywords): self {
    $this->head .= "<meta name=\"keywords\" content=\"$keywords\">";
    return $this;
  }
}