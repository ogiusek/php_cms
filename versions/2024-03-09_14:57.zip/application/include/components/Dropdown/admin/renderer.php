<?php
$content = \components()->get_content();
$component = \component(__DIR__)
  ->css_file("dropdown.css")
  ->js_file("dropdown.js");

$has_children = count($content->children) > 0;
?>

<div class="<?=$component->identifiers()?>">
  <div class="input">
    <label for="text">name</label>
    <input type="text" data-name="text" required
      maxlength="255" value="<?=$content->text?>"
      aria-label="dropdown name" title="dropdown name" />
  </div>
  <div class="input">
    <label for="link">link</label>
    <input type="text" data-name="link"
      maxlength="255" value="<?=$content->link?>"
      aria-label="dropdown link" title="dropdown link" />
  </div>
  <div class="children">
    <div class="input">
      <h3>children</h3>
      <button class="add" onclick="add_dropdown(this);">add</button>
    </div>
    <?php foreach ($content->children as $child) { ?>
      <div class="child" data-name="children[]">
        <!-- <div class="element"><php \components()->admin_render($child); ?></div> -->
        <?=\components()->admin_render($child);?>
        <div class="input">
          <button class="remove" onclick="remove_dropdown(this);">remove</button>
        </div>
      </div>
    <?php } ?>
  </div>
</div>