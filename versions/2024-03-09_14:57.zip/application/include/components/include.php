<?php
require_once "namespace.php";

function &components(): \components\IComponents {
  static $components;
  $components ??= new \components\IComponents();
  return $components;
}