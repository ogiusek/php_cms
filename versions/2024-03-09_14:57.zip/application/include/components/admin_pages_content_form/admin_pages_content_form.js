// function add_page_content(id){
function add_page_content(element, id){
  const form = element;
  const class_name = form.querySelector('[name=class_name]').value;
  
  fetch('/api/admin/pages/content/add', {
    method: 'POST',
    body: JSON.stringify({
      'page_id': id,
      'class_name': class_name
    })
  }).then(handle_fetch)
    .then((content)=>{
      notify(content, 'success');
      fetch_refresh("admin_pages_content_form", (element) => element === form.parentElement);
    })
    .catch(notify);
}

function remove_page_content(id, form_id){
  fetch('/api/admin/pages/content/delete', {
    method: 'DELETE',
    body: JSON.stringify({
      'id': id
    })
  }).then(handle_fetch)
    .then((content)=>{
      notify(content, 'success');
      document.getElementById(form_id).remove();
    })
    .catch(notify);
}