<?php
\request\verify()
  ->require_session_token()
  ->allowed_methods(["POST"])
  ->required_params(["page", "file", "order"]);
  
if(!\db\pages\create($_POST['page'], $_POST['file'], $_POST['order'])){
  \request\response()
    ->isError()
    ->setStatus(400)
    ->setContent("page already exists")
    ->send();
}

\request\response()
  ->setContent("success")
  ->send();
