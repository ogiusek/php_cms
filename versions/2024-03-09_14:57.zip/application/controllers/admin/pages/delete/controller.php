<?php
\request\verify()
  ->require_session_token()
  ->allowed_methods(["DELETE"])
  ->required_params(["id"]);

if(!\db\pages\delete($_POST['id'])){
  \request\response()
    ->isError()
    ->setStatus(400)
    ->setContent("page already exists")
    ->send();
}

\request\response()
  ->setContent("success")
  ->send();
