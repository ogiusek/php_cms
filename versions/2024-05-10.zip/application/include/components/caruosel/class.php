<?php
namespace components;

\components()->load_class("text");
\components()->load_class("image");
class caruosel{
  public array $slides = [];
}