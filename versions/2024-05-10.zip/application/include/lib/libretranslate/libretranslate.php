<?php
require_once "lib/src/LibreTranslate.php";