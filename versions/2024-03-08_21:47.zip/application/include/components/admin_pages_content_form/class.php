<?php
namespace components;
class admin_pages_content_form {
  public int $page_id;
};
