function load_edit_page_content(id) {
  const current_element_id = `page-content-${id}`;
  const current_element = document.querySelector(`#${current_element_id}`);

  // if (current_element.innerHTML !== '') return; // uncomment for better performance
  const request_params = new URLSearchParams();
  request_params.append('page_id', id);
  fetch_replace(`/api/admin/pages/content/get?${request_params.toString()}`, current_element);
}

// function add_page_content(id){
function add_page_content(element, id){
  const form = element;
  const class_name = form.querySelector('[name=class_name]').value;
  
  fetch('/api/admin/pages/content/add', {
    method: 'POST',
    body: JSON.stringify({
      'page_id': id,
      'class_name': class_name
    })
  }).then(handle_fetch)
    .then((content)=>{
      notify(content, 'success');
      load_edit_page_content(id);
      // fetch_refresh("admin_pages_content_form");
    })
    .catch(notify);
}

function remove_page_content(id, form_id){
  fetch('/api/admin/pages/content/delete', {
    method: 'DELETE',
    body: JSON.stringify({
      'id': id
    })
  }).then(handle_fetch)
    .then((content)=>{
      notify(content, 'success');
      document.getElementById(form_id).remove();
    })
    .catch(notify);
}