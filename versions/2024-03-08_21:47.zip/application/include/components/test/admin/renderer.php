<?php
$content = \components()->get_content();
?>
<div class="input">
  <input type="text" data-name="a" value="<?=$content->a?>">
</div>