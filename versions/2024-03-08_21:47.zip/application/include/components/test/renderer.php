<?php
$content = \components()->get_content();

echo $content->a;
echo "<br>";
