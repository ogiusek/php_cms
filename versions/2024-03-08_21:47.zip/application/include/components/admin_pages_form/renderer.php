<?php
$component = \component(__DIR__)
  ->css_file("admin_pages_form.css")
  ->js_file("admin_pages_form.js");

$pages = \db\pages\select_pages(true); // add element to start of pages
array_unshift($pages, ["disabled" => ""]);
?><ul class="<?=$component->identifiers()?>" data-refresh="admin_pages_form"><?php
foreach($pages as $page) {
  $is_disabled = isset($page['disabled']) ? 'disabled' : '';
  $need_default_values = ['id', 'page', 'file', 'order'];
  foreach($need_default_values as $value) {
    $page[$value] ??= '';
  } ?>
  <li>
    <form class="edit-page-form" action="javascript:edit_page(`<?=$page['id']?>`)" data-id="<?=$page['id']?>">
      <div class="row">
        <div class="input">
          <input type="text" placeholder="/start" name="page" class="page-name" aria-label="page name" required
          maxlength="255" title="Page address" value="<?=$page['page']?>" <?= $is_disabled ?>>
        </div>
        <div class="input">
          <input type="text" placeholder="start/start.php" name="file" class="page-file" aria-label="page file" required
          maxlength="255" title="Path to file" value="<?=$page['file']?>" <?= $is_disabled ?>>
        </div>
        <div class="input">
          <input type="<?=$is_disabled? 'text':'number'?>" name="order" class="page-order" aria-label="page order" required
          value="<?=$page['order']?>" title="Order" <?= $is_disabled ?>>
        </div>
      </div>
      <?php if(!$is_disabled){ ?>
      <div class="row" style="justify-content: end; margin-left: auto">
        <div class="input button">
          <button type="submit">edit</button>
          <button type="button" class="remove" onclick="delete_page(`<?=$page['id']?>`)">remove</button>
        </div>
      </div>
      <div class="page-content">
        <div class="input button">
          <button type="button" class="content-btn" onclick="toggle_edit_page_content(`<?=$page['id']?>`)">content</button>
        </div>
      </div>
      <?php } ?>
    </form>
    <div class="page-content-editor" id="page-content-<?=$page['id']?>"></div>
  </li>
<?php } ?>
</ul>