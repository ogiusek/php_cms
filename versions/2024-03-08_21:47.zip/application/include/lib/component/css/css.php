<?php
require_once "namespace.php";
function css() {
  return new \css\ICSS();
}
