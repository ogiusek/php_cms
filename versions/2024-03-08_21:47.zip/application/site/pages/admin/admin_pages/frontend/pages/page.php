<?php
$component = \component(__DIR__)
  ->css_file("pages.css")
  ->js_file("pages.js");
echo "<script>const pages_id = `".$component->id()."`;</script>";
?>

<section class="<?=$component->identifiers()?>">
  <form action="javascript:add_page(`<?=$component->id()?>`)" id="create-page-<?=$component->id()?>" class="create-form">
    <div class="input">
      <h2>Create Page</h2>
    </div>
    <div class="input">
      <input type="text" placeholder="/start" class="page-name" name="page" aria-label="page name"
      maxlength="255" title="Page address" required>
    </div>
    <div class="input">
      <input type="text" placeholder="start/start.php" class="page-file" name="file" aria-label="page file"
      value="menager.php" maxlength="255" title="Path to file" required>
    </div>
    <div class="input">
      <input type="number" class="page-order" name="order" aria-label="page order" required
      value="0" title="Order">
    </div>
    <div class="input">
      <button type="submit">Create</button>
    </div>
  </form>
  <?=\components()->render_without_content("admin_pages_form") ?>
</section>