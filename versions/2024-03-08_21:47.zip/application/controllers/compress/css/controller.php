<?php
\request\verify()
  ->allowed_methods(["GET"]);

$html = $_SESSION["css"];
header("Content-Type: text/css;");
// check do browser support gzip
if(isset($_SERVER['HTTP_ACCEPT_ENCODING']) && (strpos($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip') !== false) ) {
  $html = gzencode($html, 9);
  header("Content-Encoding: gzip");
}
echo $html;
