<?php
$component = \component(__DIR__)
  ->css_file("main_page.css");
?>

<section class="<?= $component->identifiers() ?>">
  <h1>Welcome to CMS</h1>
</section>