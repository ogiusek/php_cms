<?php
require_once "db/config.php";
require_once "lib/include.php";
require_once "components/include.php";