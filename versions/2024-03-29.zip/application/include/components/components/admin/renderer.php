<?php
$content = \components()->get_content();
$component = \component(__DIR__)
  ->css_file("components.css")
  ->js_file("components.js");
?>

<div class="<?=$component->identifiers()?>">
  <div class="input">
    <label for="content_type">component type</label>
    <select data-name="content_type" aria-label="component type">
      <?php $components = \db\components\get(); ?>
        <option value="" disabled selected>-- select --</option>
      <?php foreach($components as $component_data){ 
        $class_name = $component_data['class_name']; ?>
        <option value="<?=$class_name?>">
          <?=$class_name?>
        </option>
      <?php } ?>
    </select>
    <button onclick="add_component_to_components(this.parentNode.parentNode)" class="add">add</button>
  </div>
  <ul class="list" data-name="components">
    <?php foreach($content->components as $component_data) {
      $name = key($component_data);
      $data = $component_data[$name];
      ?>
      <div data-name="component[<?=$name?>]" class="component">
        <div class="input fixed_container">
          <button class="remove" onclick="remove_component_from_components(this)"><img src="/static/img/icons/trash.svg" alt="remove" loading="lazy" /></button>
        </div>
        <?=\components()->admin_render($data);?>
      </div>
    <?php } ?>
  </ul>
</div>