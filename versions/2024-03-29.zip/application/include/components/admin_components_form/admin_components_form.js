function delete_component(id, component_id){
  fetch('/api/admin/components/delete', {
    method: 'DELETE',
    body: JSON.stringify({
      'id': id
    })
  }).then(handle_fetch)
    .then(()=>{
      notify('Component deleted!', 'success');
      const element = document.querySelector(`.${component_id} [data-id="${id}"]`);
      element.parentElement.remove();
    })
    .catch(notify);
}

function edit_component(id, components_id){
  const form = document.querySelector(`#components-${components_id} .edit-form`);
  const class_name = form.querySelector('[name=class_name]');

  fetch('/api/admin/components/edit', {
    method: 'PATCH',
    body: JSON.stringify({
      'id': id,
      'class_name': class_name.value
    })
  }).then(handle_fetch)
    .then(()=>{
      notify('Page updated!', 'success');
    })
    .catch(notify);
}