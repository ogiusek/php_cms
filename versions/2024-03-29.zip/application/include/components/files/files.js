function redirect_files_directory(element){
  fetch_controller("files", "test").then(console.log);

  const selectParent = (e) =>
     e.hasAttribute('data-refresh') ? e : selectParent(e.parentElement);
  
  const parent = selectParent(element);
  parent.setAttribute('data-initializer', element.getAttribute('data-addr'));
  fetch_refresh("files", (element) => element === parent);
}

