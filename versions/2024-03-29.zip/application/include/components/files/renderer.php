<?php
$content = \components()->get_content();
$component = \component(__DIR__)
  ->css_file("files.css")
  ->js_file("files.js");

$dir = $_ENV['STATIC'].$content->dir;

$children = array_diff(scandir($dir), array('.'));
$files = array_filter($children, function($item) use ($dir) { return is_file($dir."/".$item); });
$directorys = array_filter($children, function($item) use ($dir) { return is_dir($dir."/".$item); });
?>

<div class="<?= $component->identifiers() ?>" data-refresh="files" data-initializer="<?=$content->dir?>">
  <div class="dark-wrapper">
    <h3 class="above-shadow">Directorys</h3>
    <form class="form" action="javascript:void(0);">
      <h4>create</h4>
    </form>
    <ul class="directorys above-shadow">
    <?php foreach ($directorys as $directory) {
      $path = $directory === ".." ? dirname($content->dir) : $content->dir."/".$directory;
      if($path === "") continue;
      ?>
      <li class="directory dark-wrapper">
        <button onclick="redirect_files_directory(this)" data-addr="<?=$path === "/" ? "" : $path?>"><?=$content->dir."/".$directory?></button>
      </li>
    <?php } ?>
    </ul>
  </div>

  <div class="dark-wrapper">
    <h3 class="above-shadow">Files</h3>
    <form class="form" action="javascript:void(0);">
      <h4>upload</h4>
    </form>
    <ul class="files">
    <?php foreach ($files as $file) { ?>
      <li class="file dark-wrapper">
        <a href="/static/<?=$content->dir."/".$file?>" target="_blank"><?=$content->dir."/".$file?></a>
      </li>
    <?php } ?>
    </ul>
  </div>
</div>