function remove_component_from_components(button){
  button.parentElement.parentElement.remove();
}

function add_component_to_components(element){
  const class_name = element.querySelector("[data-name=content_type]").value;
  const content_element = element.querySelector("[data-name=components]");
  const child = `<div data-name="component[${class_name}]" class="component">
    <div class="input fixed_container">
      <button class="remove" onclick="remove_component_from_components(this)"><img src="/static/img/icons/trash.svg" alt="remove" loading="lazy" ></button>
    </div>
    <div class="replaceMe"></div>
  </div>`;
  content_element.insertAdjacentHTML('beforeend', child);
  const new_element = [...content_element.querySelectorAll(`.replaceMe`)].at(-1);
  const url_search_params = new URLSearchParams({"class_name": class_name});
  fetch_replace(`/api/components/admin_render?${(url_search_params.toString())}`, [new_element], 'innerHTML');
}