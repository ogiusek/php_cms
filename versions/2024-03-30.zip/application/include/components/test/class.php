<?php
namespace components;
class test {
  public string $a = "brock";
};