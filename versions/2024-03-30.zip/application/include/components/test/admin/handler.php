<?php
$form_data = \components()->get_content();
$element = \components()->get_instance("test");

$element->a = $form_data["a"];

echo serialize($element);