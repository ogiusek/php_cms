function toggle_sidebar() {
  document.getElementById("sidebar").classList.toggle("hidden");
}