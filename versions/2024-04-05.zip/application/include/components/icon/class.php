<?php
namespace components;

class icon{
  public string $link = "/img/icons";
}