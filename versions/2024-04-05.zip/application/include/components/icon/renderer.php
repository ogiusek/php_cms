<?php
$component = \component(__DIR__);
$content = \components()->get_content();

$pallete = \db\colors\get_by_page_id($GLOBALS['page_id']);
$color = $pallete->colors["text-primary"];
$url_params = "url=".urlencode($content->link)."&color=".urlencode($color);
?>

<img src="/api/svg?<?=$url_params?>" alt="icon" class="<?=$component->identifiers()?>" style="height: 1.5rem;"/>
