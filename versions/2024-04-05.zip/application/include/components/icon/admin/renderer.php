<?php
$content = \components()->get_content();
$component = \component(__DIR__);
?>

<div>
  <div class="input">
    <label for="link">link</label>
    <input type="text" data-name="link" aria-label="link" value="<?=$content->link?>"/>
  </div>
</div>