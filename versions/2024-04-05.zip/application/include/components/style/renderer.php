<?php
$content = \components()->get_content();
echo $content->get_style();