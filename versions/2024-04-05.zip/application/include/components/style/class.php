<?php
namespace components;

class style{
  private array $style = [];
  public function get_style(){
    $style = "";
    foreach ($this->style as $key => $value) {
      $style .= "$key: $value;";
    }
    return $style;
  }

  public function get_styles(){
    return $this->style;
  }

  public function set_style(string $key, string $value){
    $this->style[$key] = $value;
  }
};