<?php
$content = \components()->get_content();
$component = \components()->get_instance("style");

$styles = $content['styles[]'];
foreach($styles as $data){
  $key = $data['key'];
  $value = $data['value'];
  $component->set_style($key, $value);
}

return $component;