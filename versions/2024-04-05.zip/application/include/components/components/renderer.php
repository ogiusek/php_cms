<?php
$content = \components()->get_content();
$component = \component(__DIR__)
  ->css_file("components.css");
?>
<div class="<?=$component->identifiers()?>" style="<?=\components()->render($content->get_style())?>">
<?php foreach ($content->components as $component) { ?>
  <?= \components()->render($component[key($component)])?>
<?php } ?>
</div>