<?php
$content = \components()->get_content();

$component = component(__DIR__)
  ->css_file("dropdown.css")
  ->js_file("dropdown.js");

$text = $content->text;
?>
<div class="<?=$component->identifiers()?>">
<?php
if(count($content->children) == 0){
  $link = $content->link; ?>
  <a class="dropdown-element" href="<?=$link?>"><?=$text?></a>
<?php }else{
  $dropdown_elements = $content->children;
  $children_pos = $content->children_pos; ?>
  <button class="dropdown-button">
    <span><?=$text?></span>
    <?php
      $icon = \components()->get_instance("icon");
      $icon->link = "/img/icons/dropdown.svg";
      echo \components()->render($icon);
    ?>
  </button>
  <div class="dropdown-container" style="
    justify-content:<?=$children_pos['horizontal']??"center"?>;
    align-items:<?=$children_pos['vertical']??"start"?>;
    bottom:<?=$children_pos['bottom']??"0"?>;
    left:<?=$children_pos['left']??"50%"?>;">
    <ul class="dropdown">
      <?php foreach($dropdown_elements as $dropdown_element) {
        $dropdown_element->setChildrenPos(["vertical" => "start", "horizontal" => "start", "bottom" => "100%", "left" => "100%"]);
        ?>
        <li><?=\components()->render($dropdown_element);?></li>
      <?php } ?>
    </ul>
  </div>
<?php } ?>
</div>