<?php
namespace components;

class components{
  public array $components = [];
};