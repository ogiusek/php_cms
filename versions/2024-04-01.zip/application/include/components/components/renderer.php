<?php
$content = \components()->get_content();

foreach ($content->components as $component) {
  echo \components()->render($component[key($component)]);
}