<?php
$content = \components()->get_content();
$component = \component(__DIR__)
  ->css_file("components.css")
  ->js_file("components.js");
?>

<div class="<?=$component->identifiers()?>" data-refresh="components">
  <div class="input">
    <label for="content_type">component type</label>
    <select data-name="content_type" aria-label="component type">
      <?php $components = \db\components\get(); ?>
      <option value="" disabled selected>-- select --</option>
      <?php foreach($components as $component_data){ 
        $class_name = $component_data['class_name']; ?>
        <option value="<?=$class_name?>">
          <?=$class_name?>
        </option>
      <?php } ?>
    </select>
    <div class="input" style="display: flex;flex-direction: row;gap: 0.5rem;">
      <button onclick="add_component_to_components(select_parent_component(this))" class="add">add</button>
      <button class="paste" data-alt="paste" onclick="paste_components_element(select_parent_component(this))"><img src="/static/img/icons/paste.svg" alt="paste" loading="lazy" /></button>
    </div>
  </div>
  <ul class="list" data-name="components">
    <?php foreach($content->components as $component_data) {
      $name = key($component_data);
      $data = $component_data[$name];
      ?>
      <li data-name="component[<?=$name?>]" class="component draggable" data-type="<?=$name?>">
        <div class="input fixed_container" style="display: flex; flex-direction: row; gap: 0.5rem;">
          <button class="copy" data-alt="copy" onclick="copy_components_element(this);"><img src="/static/img/icons/copy.svg" alt="copy" loading="lazy" /></button>
          <button class="drag-btn" data-alt="drag" onmouseup="drag_once(this)"><img src="/static/img/icons/move.svg" alt="move" loading="lazy"/></button>
          <button class="remove" onclick="remove_component_from_components(this)" data-alt="remove"><img src="/static/img/icons/trash.svg" alt="remove" loading="lazy" /></button>
        </div>
        <h4 style="font-size: 1.5rem; margin-top: 0"><?=$name?></h4>
        <?=\components()->admin_render($data);?>
    </li>
    <?php } ?>
  </ul>
</div>