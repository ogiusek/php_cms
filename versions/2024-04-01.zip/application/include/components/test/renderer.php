<?php
$content = \components()->get_content();
$component = \component(__DIR__);

?>
<div class="<?=$component->identifiers()?>" data-refresh="test">
  <?=$content->a?>
</div>