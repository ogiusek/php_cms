function delete_page(id){
  fetch('/api/admin/pages/delete', {
    method: 'DELETE',
    body: JSON.stringify({
      'id': id
    })
  }).then(handle_fetch)
    .then(()=>{
      notify('Page deleted!', 'success');
      document.querySelector(`.edit-page-form[data-id="${id}"]`).parentElement.remove();
    })
    .catch(notify);
}

function edit_page(id){
  const form = document.querySelector(`.edit-page-form[data-id="${id}"]`);
  const page = form.getElementsByClassName('page-name')[0];
  const file = form.getElementsByClassName('page-file')[0];
  const order = form.getElementsByClassName('page-order')[0];

  fetch('/api/admin/pages/edit', {
    method: 'PATCH',
    body: JSON.stringify({
      'id': id,
      'page': page.value,
      'file': file.value,
      'order': order.value
    })
  }).then(handle_fetch)
    .then(()=>{
      notify('Page updated!', 'success');
    })
    .catch(notify);
}

function toggle_edit_page_content(id){
  const current_element_id = `page-content-${id}`;
  [...document.querySelectorAll(`.page-content-editor:not(#${current_element_id})`)].map(e => e.classList.remove('open'));
  const current_element = document.querySelector(`#${current_element_id}`);
  current_element.classList.toggle('open');
  // refresh on toggle
  // comment to optimaze
  if(current_element.classList.contains('open')){
    fetch_refresh("admin_pages_content_form", (element) => element === current_element.firstElementChild);
  }
}

function edit_page_content(id, form_id){
  const element = document.getElementById(form_id);
  const form_data = get_form_data(element);
  const url_params = new URLSearchParams({'id': id});
  fetch(`/api/admin/pages/content/edit?${url_params.toString()}`, {
    method: 'PATCH',
    body: JSON.stringify(form_data)
  }).then(handle_fetch)
    .then((content)=>{
      notify(content, 'success');
    })
    .catch(notify);
}