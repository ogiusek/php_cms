<?php
$component = \component(__DIR__)
  ->css_file("admin_pages_content_form.css")
  ->js_file("admin_pages_content_form.js");
$content = \components()->get_content();
$page_id = $content->page_id;
?>
<div class="<?=$component->identifiers()?>" data-refresh="admin_pages_content_form" data-initializer="<?=$page_id?>">
  <form class="content-add-form form" action="javascript:void(0)" onsubmit="add_page_content(this, <?=$page_id?>)">
    <div class="input">
      <label for="class_name">component class</label>
      <select name="class_name" aria-label="class_name">
        <?php
        $components = \db\components\get();
        foreach($components as $component) { ?>
          <option value="<?=$component['class_name']?>"><?=$component['class_name']?></option>
        <?php } ?>
      </select>
    </div>
    <div class="input button">
      <button type="submit">add</button>
    </div>
  </form>

  <ul class="content-list">
  <?php
  $contents = \db\pages\content\get_by_page_id($page_id);  
  foreach($contents as $content) {
    $element_id = "content-". $content['id'];
    $content_obj = $content['content'];
    $title = get_class_of_serialized($content_obj);
    $title = \components()->get_file_name($title); ?>
    <li id="<?=$element_id?>" class="content-item">
      <h3><?=$title?></h3>
      <?php try{ ?>
      <?=\components()->admin_render($content_obj);?>
      <div class="input button" style="margin-left: auto">
        <!-- <div>
          <button><img src="/static/img/icons/arrow_up.svg" alt="arrow up"/></button>
          <button><img src="/static/img/icons/arrow_down.svg" alt="arrow down"/></button>
        </div> -->
        <button class="edit" onclick="edit_page_content(<?=$content['id']?>, '<?=$element_id?>')">edit</button>
        <button class="remove" onclick="remove_page_content(<?=$content['id']?>, '<?=$element_id?>')">remove</button>
      </div>
      <?php }catch(Throwable $e){ ?>
        <h4 class="error">Cannot render this component</h4>
      <?php } ?>
    </li>
  <?php } ?>
  </ul>
</div>